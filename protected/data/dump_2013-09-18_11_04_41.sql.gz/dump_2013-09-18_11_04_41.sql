SET FOREIGN_KEY_CHECKS = 0;

--
-- Structure for table `company`
--

DROP TABLE IF EXISTS `company`;
CREATE TABLE `company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


--
-- Data for table `company`
--

INSERT INTO `company` (`id`, `title`) VALUES
 ('1', 'Indoreka'),
 ('2', 'WEKA');



--
-- Structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL COMMENT 'Pavadinimas',
  `description` text COMMENT 'Aprašymas',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8;


--
-- Data for table `customer`
--

INSERT INTO `customer` (`id`, `title`, `description`) VALUES
 ('101', 'Klientas 1', ''),
 ('104', 'Jan Pederson', ''),
 ('105', 'Malermesterbedrift Regnbuen AS', ''),
 ('106', 'Tom Lilevik', ''),
 ('107', 'Regnbuen', ''),
 ('108', 'Vidar Sandermoen', ''),
 ('109', 'Malmesterfirmaet Pedersen & Sikkerbøl AS', ''),
 ('110', 'Pedersen & Sikkerbøl AS', ''),
 ('111', 'Tom Lilevik', ''),
 ('112', 'Ula', ''),
 ('113', 'GERFLOR', ''),
 ('114', 'BERMINGRUD', ''),
 ('115', 'ELKJØP', ''),
 ('116', 'Ronny Sjølie', ''),
 ('117', 'Øyvind Ask', ''),
 ('118', 'Torkild', '');



--
-- Structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `birthday` date NOT NULL,
  `postcode` varchar(128) DEFAULT NULL COMMENT 'Pašto kodas',
  `address` text,
  `password` varchar(512) NOT NULL,
  `username` varchar(256) NOT NULL,
  `email` varchar(512) NOT NULL,
  `usertype` varchar(128) NOT NULL,
  `phone_no` varchar(512) DEFAULT NULL COMMENT 'Telefono n. (NO)',
  `phone` varchar(512) DEFAULT NULL,
  `status` varchar(128) DEFAULT NULL COMMENT 'Statusas',
  `started` date DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `language_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `tshirt_size_id` int(11) DEFAULT NULL,
  `jersey_size_id` int(11) DEFAULT NULL,
  `trousers_size_id` int(11) DEFAULT NULL,
  `boots_size_id` int(11) DEFAULT NULL,
  `coat_size_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `size_fk1` (`tshirt_size_id`) USING BTREE,
  KEY `size_fk2` (`jersey_size_id`) USING BTREE,
  KEY `size_fk3` (`trousers_size_id`) USING BTREE,
  KEY `size_fk4` (`boots_size_id`) USING BTREE,
  KEY `size_fk5` (`coat_size_id`) USING BTREE,
  KEY `lang_fk3` (`language_id`) USING BTREE,
  KEY `comp_fk1` (`company_id`) USING BTREE,
  CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  CONSTRAINT `employee_ibfk_2` FOREIGN KEY (`language_id`) REFERENCES `language` (`id`),
  CONSTRAINT `employee_ibfk_3` FOREIGN KEY (`tshirt_size_id`) REFERENCES `size` (`id`),
  CONSTRAINT `employee_ibfk_4` FOREIGN KEY (`jersey_size_id`) REFERENCES `size` (`id`),
  CONSTRAINT `employee_ibfk_5` FOREIGN KEY (`trousers_size_id`) REFERENCES `size` (`id`),
  CONSTRAINT `employee_ibfk_6` FOREIGN KEY (`boots_size_id`) REFERENCES `size` (`id`),
  CONSTRAINT `employee_ibfk_7` FOREIGN KEY (`coat_size_id`) REFERENCES `size` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;


--
-- Data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `surname`, `birthday`, `postcode`, `address`, `password`, `username`, `email`, `usertype`, `phone_no`, `phone`, `status`, `started`, `company_id`, `language_id`, `is_active`, `tshirt_size_id`, `jersey_size_id`, `trousers_size_id`, `boots_size_id`, `coat_size_id`) VALUES
 ('21', 'Test', 'User', '0000-00-00', NULL, 'a', '$2a$04$NkdHh6Y3xC1z7VXhWwsOne3Mmqy66oS9P/AcWs.txL6G7xRwga1q2', 'tomnev', 'test@test.lt', 'admin', NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL);



--
-- Structure for table `extra_job`
--

DROP TABLE IF EXISTS `extra_job`;
CREATE TABLE `extra_job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title_lt` varchar(1024) NOT NULL COMMENT 'Pavadinimas',
  `title_no` varchar(1024) NOT NULL COMMENT 'Pavadinimas',
  `title_en` varchar(1024) NOT NULL,
  `unit` varchar(256) NOT NULL COMMENT 'Matavimo vienetas',
  PRIMARY KEY (`id`),
  KEY `lang_fk1` (`title_no`(255)) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;


--
-- Data for table `extra_job`
--

INSERT INTO `extra_job` (`id`, `title_lt`, `title_no`, `title_en`, `unit`) VALUES
 ('9', 'Durų išėmimas', 'Removing the Door', 'Removing the Door', 'h'),
 ('10', 'Laukimas kol atrakins objektą', 'Waiting before open this Object', 'Waiting before open this Object', 'h'),
 ('11', 'Dulkių valymas', 'Dust Cleaning', 'Dust Cleaning', 'h'),
 ('12', 'Valymas', 'Cleaning', 'Cleaning', 'h'),
 ('13', 'Baldų kraustymas', 'Moving Furniture', 'Moving Furniture', 'h'),
 ('14', 'Medžiagų laukimas', 'Waiting for Materials', 'Waiting for Materials', 'h');



--
-- Structure for table `job`
--

DROP TABLE IF EXISTS `job`;
CREATE TABLE `job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created` date NOT NULL COMMENT 'Sukurtas',
  `work_start` time NOT NULL DEFAULT '00:00:00' COMMENT 'Darbo pradžia',
  `work_end` time NOT NULL DEFAULT '00:00:00' COMMENT 'Darbo pabaiga',
  `travel_time` time NOT NULL DEFAULT '00:00:00' COMMENT 'Kelionės laikas',
  `parking_cost` int(11) DEFAULT '0' COMMENT 'Parkavimo išlaidos',
  `comment` text COMMENT 'Komentaras',
  `project_id` int(11) NOT NULL,
  `bonus` int(11) DEFAULT '0' COMMENT 'Bonusas',
  `employee_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `job_em1` (`employee_id`) USING BTREE,
  KEY `job_pr1` (`project_id`) USING BTREE,
  CONSTRAINT `job_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`),
  CONSTRAINT `job_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Structure for table `job_name`
--

DROP TABLE IF EXISTS `job_name`;
CREATE TABLE `job_name` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title_lt` varchar(1024) NOT NULL COMMENT 'Pavadinimas',
  `title_no` varchar(1024) NOT NULL COMMENT 'Pavadinimas',
  `title_en` varchar(1024) NOT NULL COMMENT 'Pavadinimas',
  `unit` varchar(256) NOT NULL COMMENT 'Matavimo vienetas',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;


--
-- Data for table `job_name`
--

INSERT INTO `job_name` (`id`, `title_lt`, `title_no`, `title_en`, `unit`) VALUES
 ('8', 'Šlifavimas', 'Slipe Floor', 'Slipe Floor', 'm^2'),
 ('9', 'Ruoša', 'Make ready', 'Make ready', 'h'),
 ('10', 'Medžiagų pristatymas', 'Material deliveries', 'Material deliveries', 'h'),
 ('11', 'Dangos įnešimas/išnešimas', 'Vinyl loading/unloading', 'Vinyl loading/unloading', 'h'),
 ('12', 'Senos dangos šalinimas', 'Remove old vinyl', 'Remove old vinyl', 'h'),
 ('13', 'Fleksavimas', 'Flex', 'Flex', 'm^2'),
 ('14', 'Šlifavimas', 'Slipe floor', 'Slipe floor', 'm^2'),
 ('15', 'Gruntavimas', 'Primer', 'Primer', 'm^2'),
 ('16', 'Glaistymas', 'Sparkle', 'Sparkle', 'm^2'),
 ('17', 'Klijavimas', 'Glue Vinyl', 'Glue Vinyl', 'm^2'),
 ('18', 'Dažymas', 'Painting', 'Painting', 'm^2'),
 ('19', 'Popieriaus klojimas', 'Paper cover', 'Paper cover', 'm^2'),
 ('20', 'Išklijuota Vinyl', 'Glue Vinyl', 'Glue Vinyl', 'm^2'),
 ('21', 'Išklijuota akustinio Vinyl', 'Glue acoustic vinyl', 'Glue acoustic vinyl', 'm^2'),
 ('22', 'Išklijuota sienų dangos', 'Glue walls', 'Glue walls', 'm^2'),
 ('23', 'Užlenkimų ilgis', 'Hulkil', 'Hulkil', 'm^2');



--
-- Structure for table `job_to_job_name`
--

DROP TABLE IF EXISTS `job_to_job_name`;
CREATE TABLE `job_to_job_name` (
  `job_id` int(11) NOT NULL,
  `job_name_id` int(11) NOT NULL,
  PRIMARY KEY (`job_id`,`job_name_id`),
  KEY `job_name1` (`job_name_id`) USING BTREE,
  CONSTRAINT `job_to_job_name_ibfk_1` FOREIGN KEY (`job_name_id`) REFERENCES `job_name` (`id`),
  CONSTRAINT `job_to_job_name_ibfk_2` FOREIGN KEY (`job_id`) REFERENCES `job` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Structure for table `language`
--

DROP TABLE IF EXISTS `language`;
CREATE TABLE `language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


--
-- Data for table `language`
--

INSERT INTO `language` (`id`, `title`) VALUES
 ('1', 'Lietuvių k.'),
 ('2', 'Norway'),
 ('3', 'English');



--
-- Structure for table `material`
--

DROP TABLE IF EXISTS `material`;
CREATE TABLE `material` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title_lt` varchar(1024) NOT NULL COMMENT 'Pavadinimas',
  `title_no` varchar(1024) NOT NULL COMMENT 'Pavadinimas',
  `title_en` varchar(1024) NOT NULL COMMENT 'Pavadinimas',
  `unit` varchar(256) NOT NULL COMMENT 'Matavimo vienetas',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;


--
-- Data for table `material`
--

INSERT INTO `material` (`id`, `title_lt`, `title_no`, `title_en`, `unit`) VALUES
 ('11', 'Gruntas', 'Primer', 'Primer', 'kg'),
 ('12', 'Glaistas', 'Sparkle', 'Sparkle', 'kg'),
 ('13', 'Klijai', 'Glue', 'Glue', 'kg'),
 ('14', 'Danga', 'Vinyl', 'Vinyl', 'm^2'),
 ('15', '\"Syga\"', '\"Syga\"', '\"Syga\"', 'kg'),
 ('16', 'Dažai', 'Paint', 'Paint', 'kg');



--
-- Structure for table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL COMMENT 'Pavadinimas',
  `description` text NOT NULL COMMENT 'Tekstas',
  `create_time` datetime NOT NULL COMMENT 'Data',
  `read` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Perskaitytas',
  `employee_id` int(11) NOT NULL COMMENT 'Darbuotojas',
  PRIMARY KEY (`id`),
  KEY `messa_empl` (`employee_id`) USING BTREE,
  CONSTRAINT `message_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Structure for table `month`
--

DROP TABLE IF EXISTS `month`;
CREATE TABLE `month` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` int(11) NOT NULL COMMENT 'Metai',
  `month` int(2) NOT NULL COMMENT 'Mėnuo',
  `start` date NOT NULL COMMENT 'Pradžia',
  `end` date NOT NULL COMMENT 'Pabaiga',
  `week` int(11) NOT NULL COMMENT 'Savaitė',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


--
-- Structure for table `project`
--

DROP TABLE IF EXISTS `project`;
CREATE TABLE `project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` varchar(8) DEFAULT NULL COMMENT 'Projekto ID',
  `title` varchar(1024) NOT NULL COMMENT 'Pavadinimas',
  `adress` text COMMENT 'Adresas',
  `customer_id` int(11) DEFAULT NULL COMMENT 'Klientas',
  `start` date DEFAULT NULL COMMENT 'Pradžia',
  `project_start` date DEFAULT NULL COMMENT 'Įgyvendinimo pradžia',
  `project_end` date DEFAULT NULL COMMENT 'Pabaiga',
  `status_id` int(11) DEFAULT NULL COMMENT 'Statusas',
  `is_checkout` tinyint(1) DEFAULT NULL COMMENT 'Sumokėta',
  PRIMARY KEY (`id`),
  KEY `status_fk1` (`status_id`) USING BTREE,
  KEY `customer_fk1` (`customer_id`) USING BTREE,
  CONSTRAINT `project_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  CONSTRAINT `project_ibfk_2` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8;


--
-- Data for table `project`
--

INSERT INTO `project` (`id`, `pid`, `title`, `adress`, `customer_id`, `start`, `project_start`, `project_end`, `status_id`, `is_checkout`) VALUES
 ('105', '2013001', 'WGI lager Stange', '', '101', '2011-01-01', '2011-01-01', '0000-00-00', NULL, '0'),
 ('106', '2013002', 'WGI lager Oslo', '', '101', '2011-01-01', '2011-01-01', '0000-00-00', NULL, '0'),
 ('107', '2013003', 'Kontor', '', '101', '2011-01-01', '2011-01-01', '0000-00-00', NULL, '0'),
 ('108', '2013004', 'Schwartzgate 16 Drammen', '', '105', '2013-08-21', '2013-08-21', '2013-08-21', NULL, '1'),
 ('109', '2013005', 'Jacob aalAkerBrygge', '', '104', '2013-01-02', '2013-01-02', '2016-01-04', NULL, '0'),
 ('110', '2013006', '\'\'Festningen\'\'Kongsvinger', '', '101', '2013-01-11', '2013-01-11', '2013-01-24', NULL, '1'),
 ('111', '2013007', 'Vikafrisørene', '', '101', '2013-01-19', '2013-01-19', '2013-01-22', NULL, '1'),
 ('112', '2013008', 'Hjelms gate 6 Majorstue', '', '105', '2013-02-11', '2013-02-11', '2013-04-25', NULL, '1'),
 ('113', '2013009', 'SAGA Kino', '', '109', '2013-01-23', '2013-01-23', '2013-02-19', NULL, '1'),
 ('114', '2013010', '\'\'COLOSSEUM\'\' Kino', '', '101', '2013-01-04', '2013-01-04', '2013-04-01', NULL, '1'),
 ('115', '2013011', 'Skoggata Moss', '', '106', '2013-01-17', '2013-01-17', '2013-01-17', NULL, '1'),
 ('116', '2013012', 'Bergen Barnehage', '', '101', '2013-01-29', '2013-01-29', '2013-04-24', NULL, '1'),
 ('117', '2013013', 'Tangen', '', '101', '0000-00-00', '0000-00-00', '0000-00-00', NULL, '0'),
 ('118', '2013014', 'Sagdalen', '', '101', '2013-02-05', '2013-02-05', '2013-02-05', NULL, '1'),
 ('119', '2013015', 'AkerBrygge Brygedrift', '', '104', '2013-01-04', '2013-01-04', '2013-04-29', NULL, '1'),
 ('120', '2013016', 'Tromsø \"ELKJØP\"', '', '115', '2013-02-11', '2013-02-11', '2013-03-04', NULL, '1'),
 ('121', '2013017', 'Sandermoen/Rønning/Kongsvinger', '', '101', '2013-01-17', '2013-01-17', '0000-00-00', NULL, '0');



--
-- Structure for table `setting`
--

DROP TABLE IF EXISTS `setting`;
CREATE TABLE `setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL,
  `value` varchar(256) NOT NULL,
  `employee_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;


--
-- Data for table `setting`
--

INSERT INTO `setting` (`id`, `title`, `value`, `employee_id`) VALUES
 ('11', 'jobName/admin', '75', '21'),
 ('12', 'material/admin', '25', '21'),
 ('13', 'customer/admin', '50', '21'),
 ('14', 'project/admin', '25', '21'),
 ('15', 'project/invoice', '100', '21'),
 ('16', 'job_name/admin', '50', '21'),
 ('17', 'extraJob/admin', '50', '21');



--
-- Structure for table `size`
--

DROP TABLE IF EXISTS `size`;
CREATE TABLE `size` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;


--
-- Data for table `size`
--

INSERT INTO `size` (`id`, `title`) VALUES
 ('1', 'S'),
 ('2', 'M'),
 ('3', 'L'),
 ('4', 'XL'),
 ('5', 'XXL'),
 ('6', '2XL'),
 ('7', '37'),
 ('8', '38'),
 ('9', '39'),
 ('10', '40'),
 ('11', '41'),
 ('12', '42'),
 ('13', '43'),
 ('14', '44'),
 ('15', '45'),
 ('16', '46'),
 ('17', '47');



--
-- Structure for table `status`
--

DROP TABLE IF EXISTS `status`;
CREATE TABLE `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title_lt` varchar(1024) NOT NULL COMMENT 'Pavadinimas',
  `title_no` varchar(1024) NOT NULL COMMENT 'Pavadinimas',
  `language_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


--
-- Data for table `status`
--

INSERT INTO `status` (`id`, `title_lt`, `title_no`, `language_id`) VALUES
 ('1', 'Sukurtas', '', '1'),
 ('2', 'Pradėtas', '', '1'),
 ('3', 'Užbaigtas', '', '1');


SET FOREIGN_KEY_CHECKS = 1;
